# Baybayin-Handwritten-Character-Dataset
An equal collection of handwritten Baybayin characters. (1,000 image example per character)
I do not claim any work or files in this folder.
All credits to Mr. JM Bantay (https://github.com/jmbantay)
Original files @ https://github.com/jmbantay/Baybayin-Handwritten-Character-Dataset
